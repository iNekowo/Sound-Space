### Before running the editor ###

1. Extract everything from the ZIP file into a folder
2. Download and Install '.NET Framework 4.6.1' from https://www.microsoft.com/en-US/download/details.aspx?id=49981
3. Open 'Sound Space Map Editor.exe'

### If the editor doesn't work ###

1. Try running the program as an administrator.
2. Make sure you have the latest graphics drivers
3. If it still doesn't work, there's an issue somewhere else, could also be your antivirus blocking the editor.